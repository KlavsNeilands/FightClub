from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import requests
import re
from datetime import datetime
from flask_migrate import Migrate
import pytz
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from bs4 import BeautifulSoup


app = Flask(__name__)
app.config['SECRET_KEY'] = 'Laimests777'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'



def scrape_ufc_rankings():
    url = "https://www.ufc.com/rankings"
    try:
            response = requests.get(url)
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                rankings = []
                weight_classes = soup.find_all('div', class_='view-grouping')
                
                for weight_class in weight_classes:
                    weight_class_name = weight_class.find('div', class_='view-grouping-header').text.strip()
                    
                    if "Men's Pound-for-Pound" in weight_class_name:
                        rows = weight_class.find_all('tr')
                        for row in rows:
                            rank = row.find('td', class_='views-field views-field-weight-class-rank').text.strip()
                            fighter_name = row.find('td', class_='views-field views-field-title').text.strip()
                            rankings.append({'rank': rank, 'fighter': fighter_name})
                        break 

                return rankings
            else:
                print("Failed to retrieve rankings: Status code", response.status_code)
                return None
            
    except Exception as e:
        print("An error occurred while scraping UFC rankings:", e)
        return None



class LoginAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    success = db.Column(db.Boolean)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password_hash = db.Column(db.String(100))
    locked_until = db.Column(db.DateTime, nullable=True)
    login_attempts = db.relationship('LoginAttempt', backref='user', lazy='dynamic')
    comments = db.relationship('Comment', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_account_locked(self):
        if self.locked_until is None:
            return False
        return self.locked_until > datetime.utcnow()

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    posted_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)



@app.route('/')
def index():
    return render_template('index.html')


def validate_password(password):
    pattern = r"^(?=.*[A-Z])(?=.*[\d!@#$%^&*()-_+=])[A-Za-z\d!@#$%^&*()-_+=]{8,}$"
    return bool(re.match(pattern, password))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not validate_password(password):
            flash('Password must be at least 8 characters long and contain at least one uppercase letter, one number, or one symbol.', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)

        user = User(username=username, password_hash=hashed_password)

        db.session.add(user)
        db.session.commit()

        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))  

    return render_template('register.html')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password_hash = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and not user.is_account_locked() and user.check_password(password_hash):
            login_user(user)
            flash('Logged in successfully.', 'success')
            new_attempt = LoginAttempt(success=True, user_id=user.id)
            db.session.add(new_attempt)
            user.locked_until = None  
            db.session.commit()
            return redirect(url_for('dashboard'))
        else:
            if user:
                new_attempt = LoginAttempt(success=False, user_id=user.id)
                db.session.add(new_attempt)
                if user.login_attempts.filter_by(success=False).count() >= 3: 
                    user.locked_until = datetime.utcnow() + timedelta(minutes=10)
                    flash('Account locked for 10 minutes', 'danger') 
                db.session.commit()
            flash('Invalid username or password.', 'danger')
            
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))



@app.route('/h2h-events', methods=['GET', 'POST'])
def h2h_events():

    if request.method == 'POST':
        comment_content = request.form['comment']
        new_comment = Comment(content=comment_content, user_id=current_user.id)
        db.session.add(new_comment)
        db.session.commit()
        flash('Comment added!')

        return redirect(url_for('h2h_events'))

    url = "https://mmaapi.p.rapidapi.com/api/mma/event/JDJdsPaNd/h2h/events"
    headers = {
        "X-RapidAPI-Key": "9ba50225b4msh0b60d3ad403ce94p1423c7jsnbf06943a5e36",
        "X-RapidAPI-Host": "mmaapi.p.rapidapi.com"
    }
    response = requests.get(url, headers=headers)
    print(response.json())
    events = response.json().get('events', [])

    comments = Comment.query.order_by(Comment.posted_at.desc()).all()
    
    return render_template('events.html', events=events, comments=comments)

@app.route('/dashboard')
def dashboard():
    login_attempts = current_user.login_attempts.order_by(LoginAttempt.timestamp.desc()).limit(10)
    return render_template('dashboard.html', login_attempts=login_attempts)


@app.route('/stats')
def show_stats():
    rankings = scrape_ufc_rankings()
    return render_template('stats.html', rankings=rankings)


@app.template_filter('formatdatetime')
def format_datetime(value, format='%Y-%m-%d %H:%M', tz='UTC'):
    if value.tzinfo is None:
        value = pytz.utc.localize(value)
    target_tz = pytz.timezone(tz)
    value = value.astimezone(target_tz)
    return value.strftime(format)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)